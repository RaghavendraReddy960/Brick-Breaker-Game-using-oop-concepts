only implemented ball,paddle.
not implememnted anyother.
