from colorama import init, Fore, Style, Back
init(autoreset=True)

colors = {
    'Blue': '\x1b[0;34m',
    'Green': '\x1b[0;32m',
    'Cyan': '\x1b[0;36m',
    'Red': '\x1b[0;31m',
    'Purple': '\x1b[0;35m',
    'Brown': '\x1b[0;33m',
    'Gray': '\x1b[0;37m',
    'Light Green': '\x1b[1;32m',
    'Light Cyan': '\x1b[1;36m',
    'Yellow': '\x1b[1;33m',
    'White': '\x1b[1;37m'
}
RESET = '\x1b[0m'

ALLOWED_INPUTS = ['a', 'd', 'A', 'D']

# Define scene length(vertical), width(horizontal),
# fullwidth(map length)
SC_LENGTH = 40
SC_WIDTH = 100
SC_FULLWIDTH = 500

groundx = 38

PADDLE_LENGTH=1
PADDLE_WIDTH=8
PADDLE_INIT_X=groundx
PADDLE_INIT_Y=30